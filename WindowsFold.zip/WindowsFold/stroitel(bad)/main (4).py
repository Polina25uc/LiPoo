import sys
import mysql.connector
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QLabel, QPushButton,
    QListWidget, QLineEdit, QMessageBox, QDateEdit
)
from datetime import date
from openpyxl import Workbook
from PyQt6.QtWidgets import QFileDialog


# === Подключение к MySQL через Open Server ===
db = mysql.connector.connect(
    host="localhost",         # или 127.0.0.1
    user="root",              # твой MySQL-пользователь
    password="",              # или пароль, если ты его ставил
    database="BDKvalik"   # имя БД
)
cursor = db.cursor()

class AddStageWindow(QWidget):
    def __init__(self, contract_id, parent_window):
        super().__init__()
        self.contract_id = contract_id
        self.parent_window = parent_window
        self.setWindowTitle("Добавить этап")

        layout = QVBoxLayout()

        self.name_input = QLineEdit()
        self.name_input.setPlaceholderText("Название этапа")

        self.deadline_input = QDateEdit()
        self.deadline_input.setCalendarPopup(True)
        self.deadline_input.setDate(date.today())

        self.save_btn = QPushButton("Сохранить этап")
        self.save_btn.clicked.connect(self.save_stage)

        layout.addWidget(QLabel("Название этапа:"))
        layout.addWidget(self.name_input)
        layout.addWidget(QLabel("Крайний срок:"))
        layout.addWidget(self.deadline_input)
        layout.addWidget(self.save_btn)

        self.setLayout(layout)

    def save_stage(self):
        name = self.name_input.text()
        deadline = self.deadline_input.date().toString("yyyy-MM-dd")

        if not name:
            QMessageBox.warning(self, "Ошибка", "Введите название этапа!")
            return

        cursor.execute("""
            INSERT INTO stages (contract_id, stage_name, deadline)
            VALUES (%s, %s, %s)
        """, (self.contract_id, name, deadline))
        db.commit()

        QMessageBox.information(self, "Готово", "Этап добавлен.")
        self.parent_window.load_contract_details_by_id(self.contract_id)
        self.close()

class AddActionWindow(QWidget):
    def __init__(self, contract_id, parent_window):
        super().__init__()
        self.contract_id = contract_id
        self.parent_window = parent_window
        self.setWindowTitle("Добавить действие")

        layout = QVBoxLayout()

        self.desc_input = QLineEdit()
        self.desc_input.setPlaceholderText("Описание действия")

        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)
        self.date_input.setDate(date.today())

        self.save_btn = QPushButton("Сохранить действие")
        self.save_btn.clicked.connect(self.save_action)

        layout.addWidget(QLabel("Описание действия:"))
        layout.addWidget(self.desc_input)
        layout.addWidget(QLabel("Дата действия:"))
        layout.addWidget(self.date_input)
        layout.addWidget(self.save_btn)

        self.setLayout(layout)

    def save_action(self):
        desc = self.desc_input.text()
        action_date = self.date_input.date().toString("yyyy-MM-dd")

        if not desc:
            QMessageBox.warning(self, "Ошибка", "Введите описание действия!")
            return

        cursor.execute("""
            INSERT INTO actions (contract_id, description, action_date)
            VALUES (%s, %s, %s)
        """, (self.contract_id, desc, action_date))
        db.commit()

        QMessageBox.information(self, "Готово", "Действие добавлено.")
        self.parent_window.load_contract_details_by_id(self.contract_id)
        self.close()

class EditActionWindow(QWidget):
    def __init__(self, action_id, parent_window):
        super().__init__()
        self.action_id = action_id
        self.parent_window = parent_window
        self.setWindowTitle("Редактировать действие")

        layout = QVBoxLayout()

        self.desc_input = QLineEdit()
        self.date_input = QDateEdit()
        self.date_input.setCalendarPopup(True)

        cursor.execute("SELECT description, action_date, contract_id FROM actions WHERE id = %s", (action_id,))
        result = cursor.fetchone()

        self.contract_id = result[2]
        self.desc_input.setText(result[0])
        self.date_input.setDate(result[1])

        self.save_btn = QPushButton("Сохранить изменения")
        self.save_btn.clicked.connect(self.update_action)

        layout.addWidget(QLabel("Описание действия:"))
        layout.addWidget(self.desc_input)
        layout.addWidget(QLabel("Дата:"))
        layout.addWidget(self.date_input)
        layout.addWidget(self.save_btn)

        self.setLayout(layout)

    def update_action(self):
        desc = self.desc_input.text()
        action_date = self.date_input.date().toString("yyyy-MM-dd")

        cursor.execute("""
            UPDATE actions
            SET description = %s, action_date = %s
            WHERE id = %s
        """, (desc, action_date, self.action_id))
        db.commit()

        QMessageBox.information(self, "Готово", "Действие обновлено.")
        self.parent_window.load_contract_details_by_id(self.contract_id)
        self.close()



# === Главное окно ===
class MainWindow(QWidget):
    def __init__(self, user_id, role):
        super().__init__()
        self.user_id = user_id
        self.role = role
        self.setWindowTitle("Система учёта договоров")

        self.layout = QVBoxLayout()
        self.contract_list = QListWidget()
        self.stage_list = QListWidget()
        self.action_list = QListWidget()
        self.action_list.itemClicked.connect(self.enable_action_buttons)

        self.layout.addWidget(QLabel("Договоры:"))
        self.layout.addWidget(self.contract_list)

        self.layout.addWidget(QLabel("Этапы:"))
        self.layout.addWidget(self.stage_list)

        self.layout.addWidget(QLabel("Действия:"))
        self.layout.addWidget(self.action_list)

        self.add_stage_btn = QPushButton("Добавить этап")
        self.add_stage_btn.clicked.connect(self.open_add_stage_window)
        self.add_stage_btn.setEnabled(False)
        self.layout.addWidget(self.add_stage_btn)

        self.add_action_btn = QPushButton("Добавить действие")
        self.add_action_btn.clicked.connect(self.open_add_action_window)
        self.add_action_btn.setEnabled(False)
        self.layout.addWidget(self.add_action_btn)

        self.edit_action_btn = QPushButton("Редактировать действие")
        self.edit_action_btn.clicked.connect(self.edit_selected_action)
        self.edit_action_btn.setEnabled(False)

        self.delete_action_btn = QPushButton("Удалить действие")
        self.delete_action_btn.clicked.connect(self.delete_selected_action)
        self.delete_action_btn.setEnabled(False)

        self.layout.addWidget(self.edit_action_btn)
        self.layout.addWidget(self.delete_action_btn)

        if self.role in ("admin", "user"):
            self.add_btn = QPushButton("Добавить договор")
            self.add_btn.clicked.connect(self.open_add_contract_window)
            self.layout.addWidget(self.add_btn)


        self.export_btn = QPushButton("Экспорт в Excel")
        self.export_btn.clicked.connect(self.export_to_excel)
        self.layout.addWidget(self.export_btn)

        self.setLayout(self.layout)

        self.contract_list.itemClicked.connect(self.load_contract_details)
        self.load_contracts()


    def edit_selected_action(self):
        selected = self.action_list.currentItem()
        if selected:
            text = selected.text()
            # Ожидаем формат "2024-04-10 - описание действия"
            cursor.execute("""
                SELECT id FROM actions
                WHERE contract_id = %s AND description = %s
            """, (self.selected_contract_id, text.split(" - ", 1)[1]))
            result = cursor.fetchone()
            if result:
                action_id = result[0]
                self.edit_window = EditActionWindow(action_id, self)
                self.edit_window.show()

    def delete_selected_action(self):
        selected = self.action_list.currentItem()
        if selected:
            confirm = QMessageBox.question(
                self, "Удаление",
                "Вы уверены, что хотите удалить это действие?",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No
            )
            if confirm == QMessageBox.StandardButton.Yes:
                desc = selected.text().split(" - ", 1)[1]
                cursor.execute("""
                    DELETE FROM actions
                    WHERE contract_id = %s AND description = %s
                """, (self.selected_contract_id, desc))
                db.commit()
                self.load_contract_details_by_id(self.selected_contract_id)

    def enable_action_buttons(self):
        self.edit_action_btn.setEnabled(True)
        self.delete_action_btn.setEnabled(True)

    def open_add_contract_window(self):
        self.add_window = AddContractWindow(self.user_id, self)
        self.add_window.show()

    def open_add_stage_window(self):
        if hasattr(self, "selected_contract_id"):
            self.stage_window = AddStageWindow(self.selected_contract_id, self)
            self.stage_window.show()

    def open_add_action_window(self):
        if hasattr(self, "selected_contract_id"):
            self.action_window = AddActionWindow(self.selected_contract_id, self)
            self.action_window.show()

    def load_contracts(self):
        self.contract_list.clear()
        if self.role == "admin":
            cursor.execute("SELECT id, title FROM contracts")
        else:
            cursor.execute("SELECT id, title FROM contracts WHERE created_by = %s", (self.user_id,))
        for row in cursor.fetchall():
            self.contract_list.addItem(f"{row[0]}: {row[1]}")

    def load_contract_details(self, item):
        contract_id = int(item.text().split(":")[0])
        self.selected_contract_id = contract_id
        self.add_stage_btn.setEnabled(True)
        self.add_action_btn.setEnabled(True)
        self.load_contract_details_by_id(contract_id)

    def load_contract_details_by_id(self, contract_id):
        self.stage_list.clear()
        self.action_list.clear()

        cursor.execute("SELECT stage_name, deadline FROM stages WHERE contract_id = %s", (contract_id,))
        for row in cursor.fetchall():
            self.stage_list.addItem(f"{row[0]} (до {row[1]})")

        cursor.execute("SELECT description, action_date FROM actions WHERE contract_id = %s", (contract_id,))
        for row in cursor.fetchall():
            self.action_list.addItem(f"{row[1]} - {row[0]}")

    def export_to_excel(self):
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Сохранить Excel", "", "Excel Files (*.xlsx)"
        )

        if not filepath:
            return  # Нажали "Отмена"

        # Добавим .xlsx, если нет
        if not filepath.endswith(".xlsx"):
            filepath += ".xlsx"

        try:
            wb = Workbook()
            ws_contracts = wb.active
            ws_contracts.title = "Договоры"

            ws_contracts.append(["ID", "Название"])
            cursor.execute("SELECT id, title FROM contracts")

            for row in cursor.fetchall():
                ws_contracts.append(row)

            ws_stages = wb.create_sheet("Этапы")
            ws_stages.append(["ID", "Договор ID", "Название этапа", "Крайний срок"])
            cursor.execute("SELECT id, contract_id, stage_name, deadline FROM stages")
            for row in cursor.fetchall():
                ws_stages.append(row)

            ws_actions = wb.create_sheet("Действия")
            ws_actions.append(["ID", "Договор ID", "Описание", "Дата действия"])
            cursor.execute("SELECT id, contract_id, description, action_date FROM actions")
            for row in cursor.fetchall():
                ws_actions.append(row)

            wb.save(filepath)

            QMessageBox.information(self, "Готово", "Excel-файл успешно сохранён!")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при экспорте:\n{str(e)}")


# === Окно входа ===
class LoginWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Вход в систему")

        layout = QVBoxLayout()

        self.login_input = QLineEdit()
        self.login_input.setPlaceholderText("Логин")

        self.pass_input = QLineEdit()
        self.pass_input.setPlaceholderText("Пароль")
        self.pass_input.setEchoMode(QLineEdit.EchoMode.Password)

        self.login_btn = QPushButton("Войти")
        self.login_btn.clicked.connect(self.handle_login)

        layout.addWidget(QLabel("Логин:"))
        layout.addWidget(self.login_input)
        layout.addWidget(QLabel("Пароль:"))
        layout.addWidget(self.pass_input)
        layout.addWidget(self.login_btn)

        self.setLayout(layout)

    def handle_login(self):
        login = self.login_input.text()
        password = self.pass_input.text()
        cursor.execute("SELECT id, role_id FROM users WHERE login = %s AND password = %s", (login, password))
        result = cursor.fetchone()
        if result:
            user_id = result[0]
            cursor.execute("SELECT role_name FROM roles WHERE id = %s", (result[1],))
            role = cursor.fetchone()[0]
            self.hide()
            self.main = MainWindow(user_id, role)
            self.main.show()
        else:
            QMessageBox.warning(self, "Ошибка", "Неверный логин или пароль")

class AddContractWindow(QWidget):
    def __init__(self, user_id, parent_window):
        super().__init__()
        self.user_id = user_id
        self.parent_window = parent_window
        self.setWindowTitle("Добавление договора")

        layout = QVBoxLayout()

        self.title_input = QLineEdit()
        self.title_input.setPlaceholderText("Название договора")

        self.start_date = QDateEdit()
        self.start_date.setCalendarPopup(True)
        self.start_date.setDate(date.today())

        self.end_date = QDateEdit()
        self.end_date.setCalendarPopup(True)
        self.end_date.setDate(date.today())

        self.save_btn = QPushButton("Сохранить")
        self.save_btn.clicked.connect(self.save_contract)

        layout.addWidget(QLabel("Название договора:"))
        layout.addWidget(self.title_input)
        layout.addWidget(QLabel("Дата начала:"))
        layout.addWidget(self.start_date)
        layout.addWidget(QLabel("Дата окончания:"))
        layout.addWidget(self.end_date)
        layout.addWidget(self.save_btn)

        self.setLayout(layout)

    def save_contract(self):
        title = self.title_input.text()
        start = self.start_date.date().toString("yyyy-MM-dd")
        end = self.end_date.date().toString("yyyy-MM-dd")

        if not title:
            QMessageBox.warning(self, "Ошибка", "Введите название!")
            return

        cursor.execute("""
            INSERT INTO contracts (title, start_date, end_date, created_by)
            VALUES (%s, %s, %s, %s)
        """, (title, start, end, self.user_id))
        db.commit()

        QMessageBox.information(self, "Готово", "Договор добавлен.")
        self.parent_window.load_contracts()
        self.close()


# === Запуск приложения ===
app = QApplication(sys.argv)
login = LoginWindow()
login.show()
sys.exit(app.exec())
