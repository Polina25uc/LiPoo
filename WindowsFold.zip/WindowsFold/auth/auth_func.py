import mysql.connector
import sys
from authorization import Ui_Form
from PyQt6.QtWidgets import QApplication, QWidget, QMessageBox, QLineEdit
from mysql.connector import Error


# Глобальное соединение с базой данных
try:
    con = mysql.connector.connect(
        host='localhost',
        user='root',
        password='',
        database='exam2'
    )
except Error as e:
    con = None
    print(f"Ошибка подключения к базе данных: {e}")

class AuthWindow(QWidget):
    def __init__(self):
        super().__init__()
        # Настройка UI из ui_form.py
        self.ui = Ui_Form()
        self.ui.setupUi(self)

        # Подключение кнопки к функции авторизации
        self.ui.pushButton.clicked.connect(self.authenticate)

    def authenticate(self):
        email = self.ui.lineEditMail.text().strip()
        password = self.ui.lineEditPassword.text().strip()

        if not email or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return

        try:
            cursor = con.cursor()
            # Запрос для проверки почты и пароля
            query = "SELECT id FROM users WHERE username = %s AND password = %s"
            cursor.execute(query, (email, password))
            result = cursor.fetchone()

            if result:
                QMessageBox.information(self, "Успех", "Авторизация успешна!")
                self.close()

            else:
                QMessageBox.critical(self, "Ошибка", "Неверная почта или пароль!")

            cursor.close()

        except Error as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при выполнении запроса: {e}")

    def closeEvent(self, event):
        # Закрытие соединения при выходе
        if con is not None and con.is_connected():
            con.close()
        event.accept()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = AuthWindow()
    window.show()
    sys.exit(app.exec())