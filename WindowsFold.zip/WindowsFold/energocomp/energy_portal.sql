-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 18 2025 г., 22:05
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `energy_portal`
--

-- --------------------------------------------------------

--
-- Структура таблицы `consumption_history`
--

CREATE TABLE `consumption_history` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `contract_id` int NOT NULL,
  `period` date NOT NULL,
  `consumption_value` decimal(10,2) NOT NULL,
  `status` enum('активно','приостановлено') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `consumption_history`
--

INSERT INTO `consumption_history` (`id`, `user_id`, `contract_id`, `period`, `consumption_value`, `status`) VALUES
(1, 2, 1, '2024-01-01', '150.50', 'активно'),
(2, 2, 1, '2024-02-01', '180.75', 'приостановлено'),
(3, 3, 3, '2024-03-01', '90.25', 'активно');

-- --------------------------------------------------------

--
-- Структура таблицы `contracts`
--

CREATE TABLE `contracts` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `contract_number` varchar(100) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `status` enum('active','expired','pending') NOT NULL,
  `details` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `contracts`
--

INSERT INTO `contracts` (`id`, `user_id`, `contract_number`, `start_date`, `end_date`, `status`, `details`) VALUES
(1, 2, 'CONTRACT-001', '2024-01-01', '2024-12-31', 'active', 'Договор на установку электропроводки'),
(2, 2, 'CONTRACT-002', '2024-02-01', '2024-06-30', 'expired', 'Договор на обслуживание'),
(3, 3, 'CONTRACT-003', '2024-03-01', '2024-09-30', 'pending', 'Договор на ремонт');

-- --------------------------------------------------------

--
-- Структура таблицы `payment_docs`
--

CREATE TABLE `payment_docs` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `contract_id` int NOT NULL,
  `doc_number` varchar(100) NOT NULL,
  `type` enum('оплата','возврат','штраф') NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `status` enum('pending','paid','rejected') NOT NULL,
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `file_path` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `payment_docs`
--

INSERT INTO `payment_docs` (`id`, `user_id`, `contract_id`, `doc_number`, `type`, `amount`, `status`, `created_at`, `file_path`) VALUES
(1, 2, 1, 'PAY-001', 'оплата', '5000.00', 'paid', '2025-04-18 17:37:21', '/docs/pay1.pdf'),
(2, 2, 1, 'PAY-002', 'штраф', '1000.00', 'pending', '2025-04-18 17:37:21', '/docs/pay2.pdf'),
(3, 3, 3, 'PAY-003', 'возврат', '2000.00', 'rejected', '2025-04-18 17:37:21', '/docs/pay3.pdf');

-- --------------------------------------------------------

--
-- Структура таблицы `permissions`
--

CREATE TABLE `permissions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `app_name` enum('Договоры','Платежи','Архив') NOT NULL,
  `access_level` int DEFAULT NULL
) ;

--
-- Дамп данных таблицы `permissions`
--

INSERT INTO `permissions` (`id`, `user_id`, `app_name`, `access_level`) VALUES
(1, 2, 'Договоры', 3),
(2, 2, 'Платежи', 2),
(3, 3, 'Архив', 1),
(4, 2, 'Договоры', 3);

-- --------------------------------------------------------

--
-- Структура таблицы `reports`
--

CREATE TABLE `reports` (
  `id` int NOT NULL,
  `admin_id` int NOT NULL,
  `report_type` varchar(100) NOT NULL,
  `generated_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `content` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `reports`
--

INSERT INTO `reports` (`id`, `admin_id`, `report_type`, `generated_at`, `content`) VALUES
(1, 1, 'Финансовый', '2025-04-18 17:37:21', 'Отчет по платежам за январь 2024'),
(2, 1, 'Потребление', '2025-04-18 17:37:21', 'Анализ энергопотребления за Q1');

-- --------------------------------------------------------

--
-- Структура таблицы `sessions`
--

CREATE TABLE `sessions` (
  `id` int NOT NULL,
  `user_id` int NOT NULL,
  `session_token` varchar(255) NOT NULL,
  `start_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `end_time` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `session_token`, `start_time`, `end_time`) VALUES
(1, 1, 'token_admin_123', '2025-04-18 17:37:21', NULL),
(2, 2, 'token_user1_456', '2025-04-18 17:37:21', '2025-04-18 18:37:21'),
(3, 3, 'token_user2_789', '2025-04-18 17:37:21', NULL);

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int NOT NULL,
  `email` varchar(255) NOT NULL,
  `password_hash` varchar(64) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `is_active` tinyint(1) DEFAULT '1',
  `created_at` timestamp NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `email`, `password_hash`, `role`, `is_active`, `created_at`) VALUES
(1, 'admin@example.com', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'admin', 1, '2025-04-18 17:37:21'),
(2, 'user1@example.com', '831c237928e6212bedaa4451a514ace3174562f6761f6a157a2fe5082b36e2fb', 'user', 1, '2025-04-18 17:37:21'),
(3, 'user2@example.com', 'be1b3a96a776cd32f84b3bf623230100381ebb8a8556b3aed7c7e7c599b278cf', 'user', 0, '2025-04-18 17:37:21');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `consumption_history`
--
ALTER TABLE `consumption_history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `contract_id` (`contract_id`);

--
-- Индексы таблицы `contracts`
--
ALTER TABLE `contracts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `contract_number` (`contract_number`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `payment_docs`
--
ALTER TABLE `payment_docs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `doc_number` (`doc_number`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `contract_id` (`contract_id`);

--
-- Индексы таблицы `permissions`
--
ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `reports`
--
ALTER TABLE `reports`
  ADD PRIMARY KEY (`id`),
  ADD KEY `admin_id` (`admin_id`);

--
-- Индексы таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `session_token` (`session_token`),
  ADD KEY `user_id` (`user_id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `consumption_history`
--
ALTER TABLE `consumption_history`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `contracts`
--
ALTER TABLE `contracts`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `payment_docs`
--
ALTER TABLE `payment_docs`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `permissions`
--
ALTER TABLE `permissions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT для таблицы `reports`
--
ALTER TABLE `reports`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `consumption_history`
--
ALTER TABLE `consumption_history`
  ADD CONSTRAINT `consumption_history_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `consumption_history_ibfk_2` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `contracts`
--
ALTER TABLE `contracts`
  ADD CONSTRAINT `contracts_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `payment_docs`
--
ALTER TABLE `payment_docs`
  ADD CONSTRAINT `payment_docs_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `payment_docs_ibfk_2` FOREIGN KEY (`contract_id`) REFERENCES `contracts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT;

--
-- Ограничения внешнего ключа таблицы `permissions`
--
ALTER TABLE `permissions`
  ADD CONSTRAINT `permissions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `reports`
--
ALTER TABLE `reports`
  ADD CONSTRAINT `reports_ibfk_1` FOREIGN KEY (`admin_id`) REFERENCES `users` (`id`);

--
-- Ограничения внешнего ключа таблицы `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
