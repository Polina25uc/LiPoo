# database.py
import pymysql.cursors

def get_db_connection():
    return pymysql.connect(
        host='localhost',
        user='root',
        password='',
        database='energy_portal',
        cursorclass=pymysql.cursors.DictCursor
    )