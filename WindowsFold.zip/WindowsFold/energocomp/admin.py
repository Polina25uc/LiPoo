from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QTabWidget, QTableWidget, QTableWidgetItem,
    QVBoxLayout, QPushButton, QDialog, QFormLayout, QLineEdit,
    QComboBox, QMessageBox, QSpinBox, QDateEdit, QHBoxLayout
)
from PyQt6.QtCore import Qt, QDate
from hashlib import sha256
from database import get_db_connection
import csv


class AdminWindow(QMainWindow):
    def __init__(self, admin_id):
        super().__init__()
        self.admin_id = admin_id
        self.setWindowTitle("Панель администратора")
        self.setMinimumSize(1200, 800)
        self.init_ui()

    def init_ui(self):
        tabs = QTabWidget()
        tabs.addTab(self.users_tab(), "Пользователи")
        tabs.addTab(self.permissions_tab(), "Права доступа")
        tabs.addTab(self.sessions_tab(), "Сессии")
        tabs.addTab(self.reports_tab(), "Отчеты")
        self.setCentralWidget(tabs)

    # Вкладка "Пользователи"
    def users_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        self.users_table = QTableWidget()
        self.load_users()

        btn_layout = QHBoxLayout()
        add_btn = QPushButton("Добавить", clicked=self.add_user_dialog)
        edit_btn = QPushButton("Редактировать", clicked=self.edit_user_dialog)
        extend_btn = QPushButton("Продлить доступ", clicked=self.extend_access_dialog)

        btn_layout.addWidget(add_btn)
        btn_layout.addWidget(edit_btn)
        btn_layout.addWidget(extend_btn)

        layout.addLayout(btn_layout)
        layout.addWidget(self.users_table)
        widget.setLayout(layout)
        return widget

    def load_users(self):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT u.id, u.email, u.role, u.is_active, 
                               MAX(c.end_date) as access_end
                        FROM users u
                        LEFT JOIN contracts c ON u.id = c.user_id
                        GROUP BY u.id
                    """)
                    users = cursor.fetchall()

            self.users_table.setColumnCount(5)
            self.users_table.setHorizontalHeaderLabels(
                ["ID", "Email", "Роль", "Активен", "Доступ до"]
            )
            self.users_table.setRowCount(len(users))

            for row, user in enumerate(users):
                self.users_table.setItem(row, 0, QTableWidgetItem(str(user['id'])))
                self.users_table.setItem(row, 1, QTableWidgetItem(user['email']))
                self.users_table.setItem(row, 2, QTableWidgetItem(user['role']))
                self.users_table.setItem(row, 3, QTableWidgetItem("Да" if user['is_active'] else "Нет"))
                self.users_table.setItem(row, 4, QTableWidgetItem(str(user['access_end'])))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # Вкладка "Права доступа"
    def permissions_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        self.permissions_table = QTableWidget()
        self.load_permissions()

        edit_btn = QPushButton("Изменить права", clicked=self.edit_permissions_dialog)
        layout.addWidget(edit_btn)
        layout.addWidget(self.permissions_table)
        widget.setLayout(layout)
        return widget

    def load_permissions(self):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT p.user_id, u.email, p.app_name, p.access_level 
                        FROM permissions p
                        JOIN users u ON p.user_id = u.id
                    """)
                    permissions = cursor.fetchall()

            self.permissions_table.setColumnCount(4)
            self.permissions_table.setHorizontalHeaderLabels(
                ["ID", "Пользователь", "Приложение", "Уровень доступа"]
            )
            self.permissions_table.setRowCount(len(permissions))

            for row, perm in enumerate(permissions):
                self.permissions_table.setItem(row, 0, QTableWidgetItem(str(perm['user_id'])))
                self.permissions_table.setItem(row, 1, QTableWidgetItem(perm['email']))
                self.permissions_table.setItem(row, 2, QTableWidgetItem(perm['app_name']))
                self.permissions_table.setItem(row, 3, QTableWidgetItem(str(perm['access_level'])))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # Вкладка "Сессии"
    def sessions_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        self.sessions_table = QTableWidget()
        self.load_sessions()

        limit_btn = QPushButton("Установить лимит", clicked=self.set_session_limit_dialog)
        layout.addWidget(limit_btn)
        layout.addWidget(self.sessions_table)
        widget.setLayout(layout)
        return widget

    def load_sessions(self):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute("""
                        SELECT s.user_id, u.email, s.start_time, s.end_time 
                        FROM sessions s
                        JOIN users u ON s.user_id = u.id
                    """)
                    sessions = cursor.fetchall()

            self.sessions_table.setColumnCount(4)
            self.sessions_table.setHorizontalHeaderLabels(
                ["ID", "Пользователь", "Начало", "Окончание"]
            )
            self.sessions_table.setRowCount(len(sessions))

            for row, session in enumerate(sessions):
                self.sessions_table.setItem(row, 0, QTableWidgetItem(str(session['user_id'])))
                self.sessions_table.setItem(row, 1, QTableWidgetItem(session['email']))
                self.sessions_table.setItem(row, 2, QTableWidgetItem(str(session['start_time'])))
                self.sessions_table.setItem(row, 3, QTableWidgetItem(str(session['end_time'])))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # Диалоги и вспомогательные функции
    def add_user_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Новый пользователь")
        layout = QFormLayout()

        email = QLineEdit()
        password = QLineEdit(echoMode=QLineEdit.EchoMode.Password)
        role = QComboBox()
        role.addItems(['user', 'admin'])

        btn_save = QPushButton("Сохранить", clicked=lambda: self.save_user(
            email.text(),
            password.text(),
            role.currentText(),
            dialog
        ))

        layout.addRow("Email:", email)
        layout.addRow("Пароль:", password)
        layout.addRow("Роль:", role)
        layout.addRow(btn_save)
        dialog.setLayout(layout)
        dialog.exec()

    def save_user(self, email, password, role, dialog):
        if not email.strip() or not password.strip():
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return

        password_hash = sha256(password.encode()).hexdigest()
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "INSERT INTO users (email, password_hash, role) VALUES (%s, %s, %s)",
                        (email, password_hash, role))
                    conn.commit()
                    self.load_users()
                    dialog.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка БД: {str(e)}")

    def edit_permissions_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Редактирование прав")
        layout = QFormLayout()

        user_id = QLineEdit(placeholderText="ID пользователя")
        app = QComboBox()
        app.addItems(['Договоры', 'Платежи', 'Архив'])
        access = QComboBox()
        access.addItems(['Чтение (1)', 'Редактирование (2)', 'Полный доступ (3)'])

        btn_save = QPushButton("Сохранить", clicked=lambda: self.save_permission(
            user_id.text(),
            app.currentText(),
            access.currentIndex() + 1,
            dialog
        ))

        layout.addRow("ID пользователя:", user_id)
        layout.addRow("Приложение:", app)
        layout.addRow("Уровень доступа:", access)
        layout.addRow(btn_save)
        dialog.setLayout(layout)
        dialog.exec()

    def save_permission(self, user_id, app_name, access_level, dialog):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "INSERT INTO permissions (user_id, app_name, access_level) "
                        "VALUES (%s, %s, %s) ON DUPLICATE KEY UPDATE access_level = %s",
                        (user_id, app_name, access_level, access_level))
                    conn.commit()
                    self.load_permissions()
                    dialog.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def set_session_limit_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Лимит сессий")
        layout = QFormLayout()

        user_id = QLineEdit(placeholderText="ID пользователя")
        max_sessions = QSpinBox()
        max_sessions.setRange(1, 10)

        btn_save = QPushButton("Сохранить", clicked=lambda: self.save_session_limit(
            user_id.text(),
            max_sessions.value(),
            dialog
        ))

        layout.addRow("ID пользователя:", user_id)
        layout.addRow("Макс. сессий:", max_sessions)
        layout.addRow(btn_save)
        dialog.setLayout(layout)
        dialog.exec()

    def save_session_limit(self, user_id, max_sessions, dialog):
        # Реализуйте логику сохранения в БД
        QMessageBox.information(self, "Успех", "Лимит установлен!")
        dialog.close()

    def extend_access_dialog(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Продление доступа")
        layout = QFormLayout()

        user_id = QLineEdit(placeholderText="ID пользователя")
        new_date = QDateEdit(calendarPopup=True)
        new_date.setDate(QDate.currentDate().addMonths(1))

        btn_save = QPushButton("Сохранить", clicked=lambda: self.save_access_extension(
            user_id.text(),
            new_date.date().toString("yyyy-MM-dd"),
            dialog
        ))

        layout.addRow("ID пользователя:", user_id)
        layout.addRow("Новая дата:", new_date)
        layout.addRow(btn_save)
        dialog.setLayout(layout)
        dialog.exec()

    def save_access_extension(self, user_id, new_date, dialog):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "UPDATE contracts SET end_date = %s WHERE user_id = %s",
                        (new_date, user_id))
                    conn.commit()
                    QMessageBox.information(self, "Успех", "Доступ продлен!")
                    dialog.close()
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # Вкладка "Отчеты"
    def reports_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        report_types = QComboBox()
        report_types.addItems([
            "Активные пользователи",
            "Финансовые операции",
            "История сессий"
        ])

        generate_btn = QPushButton("Сгенерировать", clicked=lambda: self.generate_report(
            report_types.currentText()
        ))

        layout.addWidget(report_types)
        layout.addWidget(generate_btn)
        widget.setLayout(layout)
        return widget

    def generate_report(self, report_type):
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    if report_type == "Активные пользователи":
                        cursor.execute("""
                            SELECT u.id, u.email, COUNT(s.id) as sessions 
                            FROM users u
                            LEFT JOIN sessions s ON u.id = s.user_id
                            GROUP BY u.id
                        """)
                        filename = "active_users.csv"
                        headers = ["ID", "Email", "Сессий"]

                    elif report_type == "Финансовые операции":
                        cursor.execute("SELECT * FROM payment_docs")
                        filename = "payments.csv"
                        headers = ["ID", "Документ", "Сумма", "Статус"]

                    elif report_type == "История сессий":
                        cursor.execute("""
                            SELECT u.email, s.start_time, s.end_time 
                            FROM sessions s
                            JOIN users u ON s.user_id = u.id
                        """)
                        filename = "sessions_history.csv"
                        headers = ["Пользователь", "Начало", "Окончание"]

                    data = cursor.fetchall()

            with open(filename, 'w', newline='') as f:
                writer = csv.writer(f, delimiter=';')
                writer.writerow(headers)
                for row in data:
                    writer.writerow(row.values())

            QMessageBox.information(self, "Успех", f"Отчет сохранен в {filename}")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def edit_user_dialog(self):
        selected_row = self.users_table.currentRow()
        if selected_row == -1:
            QMessageBox.warning(self, "Ошибка", "Выберите пользователя для редактирования!")
            return

        user_id = self.users_table.item(selected_row, 0).text()

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT email, role, is_active FROM users WHERE id = %s",
                        (user_id,))
                    user_data = cursor.fetchone()

                    dialog = QDialog(self)
                    dialog.setWindowTitle("Редактирование пользователя")
                    layout = QFormLayout()

                    # Поля для редактирования
                    email = QLineEdit(user_data['email'])
                    role = QComboBox()
                    role.addItems(['user', 'admin'])
                    role.setCurrentText(user_data['role'])

                    is_active = QComboBox()
                    is_active.addItems(['Активен', 'Заблокирован'])
                    is_active.setCurrentIndex(0 if user_data['is_active'] else 1)

                    btn_save = QPushButton("Сохранить", clicked=lambda: self.save_user_edit(
                        user_id,
                        email.text(),
                        role.currentText(),
                        is_active.currentIndex() == 0,
                        dialog
                    ))

                    layout.addRow("Email:", email)
                    layout.addRow("Роль:", role)
                    layout.addRow("Статус:", is_active)
                    layout.addRow(btn_save)
                    dialog.setLayout(layout)
                    dialog.exec()

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    def save_user_edit(self, user_id, email, role, is_active, dialog):
        if not email.strip():
            QMessageBox.warning(self, "Ошибка", "Email не может быть пустым!")
            return

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "UPDATE users SET email = %s, role = %s, is_active = %s WHERE id = %s",
                        (email, role, is_active, user_id))
                    conn.commit()
                    self.load_users()
                    dialog.close()
                    QMessageBox.information(self, "Успех", "Данные обновлены!")
        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка БД: {str(e)}")
