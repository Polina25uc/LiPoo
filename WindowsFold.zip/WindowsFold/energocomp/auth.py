from PyQt6.QtWidgets import QWidget, QVBoxLayout, QLineEdit, QPushButton, QLabel, QMessageBox
from PyQt6.QtCore import Qt
from hashlib import sha256
from database import get_db_connection


class AuthWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Авторизация")
        self.setFixedSize(350, 180)
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout()
        self.email_input = QLineEdit(placeholderText="Email")
        self.password_input = QLineEdit(placeholderText="Пароль", echoMode=QLineEdit.EchoMode.Password)
        self.login_btn = QPushButton("Войти", clicked=self.authenticate)

        layout.addWidget(QLabel("Личный кабинет", alignment=Qt.AlignmentFlag.AlignCenter))
        layout.addWidget(self.email_input)
        layout.addWidget(self.password_input)
        layout.addWidget(self.login_btn)
        self.setLayout(layout)

    def authenticate(self):
        email = self.email_input.text()
        password = sha256(self.password_input.text().encode()).hexdigest()

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT id, role FROM users WHERE email = %s AND password_hash = %s",
                        (email, password)
                    )
                    user = cursor.fetchone()

            if user:
                self.close()  # Закрываем окно авторизации
                if user["role"] == "admin":
                    from admin import AdminWindow  # Импорт внутри условия!
                    self.admin_window = AdminWindow(user["id"])
                    self.admin_window.show()
                else:
                    from user import UserWindow  # Импорт внутри условия!
                    self.user_window = UserWindow(user["id"])
                    self.user_window.show()
            else:
                QMessageBox.warning(self, "Ошибка", "Неверные учетные данные!")

        except Exception as e:
            QMessageBox.critical(self, "Ошибка БД", str(e))