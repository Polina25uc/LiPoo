from PyQt6.QtWidgets import (
    QMainWindow, QWidget, QTabWidget, QTableWidget,
    QTableWidgetItem, QVBoxLayout, QPushButton,
    QFileDialog, QMessageBox, QLineEdit, QHBoxLayout
)
from PyQt6.QtCore import Qt
from database import get_db_connection
from datetime import datetime


class UserWindow(QMainWindow):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.setWindowTitle("Личный кабинет")
        self.setMinimumSize(1000, 800)
        self.init_ui()

    def init_ui(self):
        tabs = QTabWidget()
        tabs.addTab(self.contracts_tab(), "Договоры")
        tabs.addTab(self.payments_tab(), "Платежи")
        tabs.addTab(self.consumption_tab(), "История потребления")
        tabs.addTab(self.finance_tab(), "Финансовые операции")
        tabs.addTab(self.archive_tab(), "Архив")
        self.setCentralWidget(tabs)

    # Договоры
    def contracts_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["Номер", "Начало", "Окончание", "Статус"])

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    # Убедитесь, что столбец contract_number существует в таблице contracts
                    cursor.execute(
                        "SELECT contract_number, start_date, end_date, status "
                        "FROM contracts WHERE user_id = %s",
                        (self.user_id,)
                    )
                    contracts = cursor.fetchall()

                    table.setRowCount(len(contracts))
                    for row, contract in enumerate(contracts):
                        # Проверка наличия ключей в словаре contract
                        contract_number = contract.get('contract_number', 'N/A')
                        start_date = contract.get('start_date', 'N/A')
                        end_date = contract.get('end_date', 'N/A')
                        status = contract.get('status', 'N/A')

                        # Заполнение таблицы
                        table.setItem(row, 0, QTableWidgetItem(str(contract_number)))
                        table.setItem(row, 1, QTableWidgetItem(str(start_date)))
                        table.setItem(row, 2, QTableWidgetItem(str(end_date)))
                        table.setItem(row, 3, QTableWidgetItem(str(status)))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при загрузке данных: {str(e)}")

        layout.addWidget(table)
        widget.setLayout(layout)
        return widget

    # Платежи
    def payments_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        upload_btn = QPushButton("Загрузить документ", clicked=self.upload_document)
        table = QTableWidget()
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels(["Документ", "Тип", "Сумма", "Статус", "Файл"])

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT doc_number, type, amount, status, file_path "
                        "FROM payment_docs WHERE user_id = %s",
                        (self.user_id,)
                    )
                    payments = cursor.fetchall()

                    table.setRowCount(len(payments))
                    for row, payment in enumerate(payments):
                        table.setItem(row, 0, QTableWidgetItem(payment['doc_number']))
                        table.setItem(row, 1, QTableWidgetItem(payment.get('type', 'N/A')))  # Обработка отсутствующего типа
                        table.setItem(row, 2, QTableWidgetItem(f"{payment['amount']} ₽"))
                        table.setItem(row, 3, QTableWidgetItem(payment['status']))
                        table.setItem(row, 4, QTableWidgetItem(payment.get('file_path', '')))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

        layout.addWidget(upload_btn)
        layout.addWidget(table)
        widget.setLayout(layout)
        return widget

    # История потребления
    def consumption_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setColumnCount(4)
        table.setHorizontalHeaderLabels(["Период", "Потребление (кВт·ч)", "Договор", "Статус"])

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT ch.period, ch.consumption_value, c.contract_number, ch.status "
                        "FROM consumption_history ch "
                        "JOIN contracts c ON ch.contract_id = c.id "
                        "WHERE ch.user_id = %s",
                        (self.user_id,)
                    )
                    data = cursor.fetchall()

                    table.setRowCount(len(data))
                    for row, item in enumerate(data):
                        table.setItem(row, 0, QTableWidgetItem(str(item['period']))),
                        table.setItem(row, 1, QTableWidgetItem(str(item['consumption_value']))),
                        table.setItem(row, 2, QTableWidgetItem(item['contract_number'])),
                        table.setItem(row, 3, QTableWidgetItem(item.get('status', 'N/A')))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

        layout.addWidget(table)
        widget.setLayout(layout)
        return widget

    # Финансовые операции
    def finance_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        table = QTableWidget()
        table.setColumnCount(5)
        table.setHorizontalHeaderLabels(["Дата", "Тип", "Сумма", "Договор", "Статус"])

        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT p.created_at, p.type, p.amount, c.contract_number, p.status "
                        "FROM payment_docs p "
                        "JOIN contracts c ON p.contract_id = c.id "
                        "WHERE p.user_id = %s",
                        (self.user_id,)
                    )
                    data = cursor.fetchall()

                    table.setRowCount(len(data))
                    for row, item in enumerate(data):
                        table.setItem(row, 0, QTableWidgetItem(str(item['created_at']))),
                        table.setItem(row, 1, QTableWidgetItem(item.get('type', 'N/A'))),
                        table.setItem(row, 2, QTableWidgetItem(f"{item['amount']} ₽")),
                        table.setItem(row, 3, QTableWidgetItem(item['contract_number'])),
                        table.setItem(row, 4, QTableWidgetItem(item['status']))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

        layout.addWidget(table)
        widget.setLayout(layout)
        return widget

    # Электронный архив
    def archive_tab(self):
        widget = QWidget()
        layout = QVBoxLayout()

        search_layout = QHBoxLayout()
        self.search_input = QLineEdit(placeholderText="Поиск по документам...")
        search_btn = QPushButton("Найти", clicked=self.search_documents)

        self.archive_table = QTableWidget()
        self.archive_table.setColumnCount(4)
        self.archive_table.setHorizontalHeaderLabels(["Документ", "Дата", "Тип", "Статус"])

        search_layout.addWidget(self.search_input)
        search_layout.addWidget(search_btn)

        layout.addLayout(search_layout)
        layout.addWidget(self.archive_table)
        widget.setLayout(layout)
        return widget

    def search_documents(self):
        search_text = self.search_input.text()
        try:
            with get_db_connection() as conn:
                with conn.cursor() as cursor:
                    cursor.execute(
                        "SELECT doc_number, created_at, type, status "
                        "FROM payment_docs "
                        "WHERE user_id = %s AND doc_number LIKE %s",
                        (self.user_id, f"%{search_text}%")
                    )
                    results = cursor.fetchall()

                    self.archive_table.setRowCount(len(results))
                    for row, item in enumerate(results):
                        self.archive_table.setItem(row, 0, QTableWidgetItem(item['doc_number'])),
                        self.archive_table.setItem(row, 1, QTableWidgetItem(str(item['created_at']))),
                        self.archive_table.setItem(row, 2, QTableWidgetItem(item.get('type', 'N/A'))),
                        self.archive_table.setItem(row, 3, QTableWidgetItem(item['status']))

        except Exception as e:
            QMessageBox.critical(self, "Ошибка", str(e))

    # Загрузка документов
    def upload_document(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Выберите файл", "", "PDF Files (*.pdf)")
        if file_path:
            try:
                doc_number = f"DOC-{datetime.now().strftime('%Y%m%d%H%M%S')}"

                with get_db_connection() as conn:
                    with conn.cursor() as cursor:
                        cursor.execute(
                            "INSERT INTO payment_docs (user_id, doc_number, type, amount, status, file_path) "
                            "VALUES (%s, %s, %s, %s, %s, %s)",
                            (self.user_id, doc_number, 'оплата', 0.0, 'pending', file_path)
                        )
                        conn.commit()
                QMessageBox.information(self, "Успех", "Документ загружен!")
            except Exception as e:
                QMessageBox.critical(self, "Ошибка", str(e))