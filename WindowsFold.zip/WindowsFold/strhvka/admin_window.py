from PyQt6.QtWidgets import QMainWindow, QTableWidget, QTableWidgetItem, QPushButton, QLineEdit, QComboBox, QFormLayout, QVBoxLayout, QWidget, QMessageBox
from PyQt6.QtCore import Qt
from db import Database

class AdminWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Панель администратора")
        self.setGeometry(100, 100, 1000, 600)

        # Основной виджет и layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Форма добавления пользователя
        form_layout = QFormLayout()
        self.username_input = QLineEdit()
        self.password_input = QLineEdit()
        self.email_input = QLineEdit()
        self.role_input = QComboBox()
        self.role_input.addItems(["user", "admin"])
        add_user_button = QPushButton("Добавить пользователя")
        add_user_button.clicked.connect(self.add_user)

        form_layout.addRow("Имя пользователя:", self.username_input)
        form_layout.addRow("Пароль:", self.password_input)
        form_layout.addRow("Email:", self.email_input)
        form_layout.addRow("Роль:", self.role_input)
        form_layout.addRow(add_user_button)
        layout.addLayout(form_layout)

        # Фильтр по сумме
        self.amount_filter = QLineEdit()
        filter_button = QPushButton("Фильтровать по сумме")
        filter_button.clicked.connect(self.load_requests)
        layout.addWidget(self.amount_filter)
        layout.addWidget(filter_button)

        # Таблица заявок
        self.request_table = QTableWidget()
        self.request_table.setColumnCount(8)
        self.request_table.setHorizontalHeaderLabels(["ID", "Клиент", "Тип страхования", "Дата", "Сумма", "Статус", "История", "Удалить"])
        layout.addWidget(self.request_table)

        # Таблица страховок
        self.insurance_table = QTableWidget()
        self.insurance_table.setColumnCount(3)
        self.insurance_table.setHorizontalHeaderLabels(["ID", "Название", "Описание"])
        layout.addWidget(self.insurance_table)

        # Таблица клиентов
        self.client_table = QTableWidget()
        self.client_table.setColumnCount(4)
        self.client_table.setHorizontalHeaderLabels(["ID", "ФИО", "Телефон", "Email"])
        layout.addWidget(self.client_table)

        # Кнопка проверки дубликатов
        duplicates_button = QPushButton("Проверить дубликаты")
        duplicates_button.clicked.connect(self.check_duplicates)
        layout.addWidget(duplicates_button)

        # Кнопка выхода
        logout_button = QPushButton("Выйти")
        logout_button.clicked.connect(self.close)
        layout.addWidget(logout_button)

        # Загрузка данных
        self.load_requests()
        self.load_insurance_types()
        self.load_clients()

    def add_user(self):
        username = self.username_input.text()
        password = self.password_input.text()
        email = self.email_input.text()
        role = self.role_input.currentText()
        if username and password and email:
            self.db.add_user(username, password, email, role)
            QMessageBox.information(self, "Успех", "Пользователь добавлен")
            self.username_input.clear()
            self.password_input.clear()
            self.email_input.clear()
        else:
            QMessageBox.critical(self, "Ошибка", "Заполните все поля")

    def load_requests(self):
        min_amount = self.amount_filter.text() if self.amount_filter.text() else None
        requests = self.db.get_all_requests(min_amount)
        self.request_table.setRowCount(len(requests))

        for row, request in enumerate(requests):
            self.request_table.setItem(row, 0, QTableWidgetItem(str(request['id'])))
            self.request_table.setItem(row, 1, QTableWidgetItem(request['full_name']))
            self.request_table.setItem(row, 2, QTableWidgetItem(request['insurance_type']))
            self.request_table.setItem(row, 3, QTableWidgetItem(str(request['request_date'])))
            self.request_table.setItem(row, 4, QTableWidgetItem(str(request['amount'])))
            self.request_table.setItem(row, 5, QTableWidgetItem(request['status']))

            # Кнопка для истории
            history_button = QPushButton("Показать историю")
            history_button.clicked.connect(lambda _, rid=request['id']: self.show_history(rid))
            self.request_table.setCellWidget(row, 6, history_button)

            # Кнопка для удаления
            delete_button = QPushButton("Удалить")
            delete_button.clicked.connect(lambda _, rid=request['id']: self.delete_request(rid))
            self.request_table.setCellWidget(row, 7, delete_button)

        self.request_table.resizeColumnsToContents()

    def load_insurance_types(self):
        insurance_types = self.db.get_insurance_types()
        self.insurance_table.setRowCount(len(insurance_types))

        for row, insurance in enumerate(insurance_types):
            self.insurance_table.setItem(row, 0, QTableWidgetItem(str(insurance['id'])))
            self.insurance_table.setItem(row, 1, QTableWidgetItem(insurance['name']))
            self.insurance_table.setItem(row, 2, QTableWidgetItem(insurance['description']))

        self.insurance_table.resizeColumnsToContents()

    def load_clients(self):
        clients = self.db.get_clients()
        self.client_table.setRowCount(len(clients))

        for row, client in enumerate(clients):
            self.client_table.setItem(row, 0, QTableWidgetItem(str(client['id'])))
            self.client_table.setItem(row, 1, QTableWidgetItem(client['full_name']))
            self.client_table.setItem(row, 2, QTableWidgetItem(client['phone'] or ""))
            self.client_table.setItem(row, 3, QTableWidgetItem(client['email'] or ""))

        self.client_table.resizeColumnsToContents()

    def show_history(self, request_id):
        history = self.db.get_request_history(request_id)
        history_text = "\n".join([f"{h['timestamp']}: {h['message']}" for h in history])
        QMessageBox.information(self, "История заявки", history_text or "История пуста")

    def delete_request(self, request_id):
        reply = QMessageBox.question(self, "Подтверждение", "Удалить заявку?", QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if reply == QMessageBox.StandardButton.Yes:
            self.db.delete_request(request_id)
            self.load_requests()
            QMessageBox.information(self, "Успех", "Заявка удалена")

    def check_duplicates(self):
        duplicates = self.db.check_duplicate_requests()
        if duplicates:
            duplicates_text = "\n".join([f"Клиент ID: {d['client_id']}, Тип: {d['insurance_type_id']}, Дата: {d['request_date']}, Кол-во: {d['count']}" for d in duplicates])
            QMessageBox.warning(self, "Дубликаты", duplicates_text)
        else:
            QMessageBox.information(self, "Дубликаты", "Повторяющиеся заявки не найдены")