import mysql.connector
from mysql.connector import Error
from datetime import datetime

class Database:
    def __init__(self):
        self.connection = None
        try:
            self.connection = mysql.connector.connect(
                host="localhost",
                user="root",
                password="",
                database="insurance_system"
            )
        except Error as e:
            print(f"Ошибка подключения к базе данных: {e}")

    def get_client_id_by_user(self, user_id):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT id FROM Clients 
            WHERE email = (SELECT email FROM Users WHERE id = %s)
        """, (user_id,))
        result = cursor.fetchone()
        cursor.close()
        return result['id'] if result else None

    def get_user_requests(self, client_id):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT r.id, r.request_date, r.amount, r.status, it.name AS insurance_type 
            FROM Requests r 
            JOIN InsuranceTypes it ON r.insurance_type_id = it.id 
            WHERE r.client_id = %s
        """, (client_id,))
        result = cursor.fetchall()
        cursor.close()
        return result

    def get_request_history(self, request_id):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT timestamp, message 
            FROM RequestHistory 
            WHERE request_id = %s
        """, (request_id,))
        result = cursor.fetchall()
        cursor.close()
        return result

    def upload_attachment(self, request_id, file_path):
        cursor = self.connection.cursor()
        upload_time = datetime.now().strftime('%Y-%m-d-%H:%M:%S')
        cursor.execute("""
            INSERT INTO Attachments (request_id, file_path, upload_time) 
            VALUES (%s, %s, %s)
        """, (request_id, file_path, upload_time))
        self.connection.commit()
        cursor.close()

    def add_user(self, username, password, email, role):
        cursor = self.connection.cursor()
        cursor.execute("""
            INSERT INTO Users (username, password, role, email) 
            VALUES (%s, %s, %s, %s)
        """, (username, password, role, email))
        self.connection.commit()
        cursor.close()

    def get_all_requests(self, min_amount=None):
        cursor = self.connection.cursor(dictionary=True)
        query = """
            SELECT r.id, c.full_name, it.name AS insurance_type, r.request_date, r.amount, r.status 
            FROM Requests r 
            JOIN Clients c ON r.client_id = c.id 
            JOIN InsuranceTypes it ON r.insurance_type_id = it.id
        """
        params = []
        if min_amount:
            query += " WHERE r.amount >= %s"
            params.append(min_amount)
        cursor.execute(query, params)
        result = cursor.fetchall()
        cursor.close()
        return result

    def get_insurance_types(self):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM InsuranceTypes")
        result = cursor.fetchall()
        cursor.close()
        return result

    def get_clients(self):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("SELECT * FROM Clients")
        result = cursor.fetchall()
        cursor.close()
        return result

    def delete_request(self, request_id):
        cursor = self.connection.cursor()
        cursor.execute("DELETE FROM Attachments WHERE request_id = %s", (request_id,))
        cursor.execute("DELETE FROM RequestHistory WHERE request_id = %s", (request_id,))
        cursor.execute("DELETE FROM Requests WHERE id = %s", (request_id,))
        self.connection.commit()
        cursor.close()

    def check_duplicate_requests(self):
        cursor = self.connection.cursor(dictionary=True)
        cursor.execute("""
            SELECT client_id, insurance_type_id, request_date, COUNT(*) as count 
            FROM Requests 
            GROUP BY client_id, insurance_type_id, request_date 
            HAVING count > 1
        """)
        result = cursor.fetchall()
        cursor.close()
        return result

    def __del__(self):
        if self.connection and self.connection.is_connected():
            self.connection.close()