from PyQt6.QtWidgets import QMainWindow, QTableWidget, QTableWidgetItem, QPushButton, QFileDialog, QMessageBox, QVBoxLayout, QWidget
from PyQt6.QtCore import Qt
from db import Database
import os

class UserWindow(QMainWindow):
    def __init__(self, user_id):
        super().__init__()
        self.user_id = user_id
        self.db = Database()
        self.init_ui()

    def init_ui(self):
        self.setWindowTitle("Панель пользователя")
        self.setGeometry(100, 100, 800, 600)

        # Основной виджет и layout
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        layout = QVBoxLayout(central_widget)

        # Таблица заявок
        self.table = QTableWidget()
        self.table.setColumnCount(7)
        self.table.setHorizontalHeaderLabels(["ID", "Дата", "Тип страхования", "Сумма", "Статус", "История", "Загрузить файл"])
        layout.addWidget(self.table)

        # Кнопка выхода
        logout_button = QPushButton("Выйти")
        logout_button.clicked.connect(self.close)
        layout.addWidget(logout_button)

        # Загрузка данных
        self.load_requests()

    def load_requests(self):
        client_id = self.db.get_client_id_by_user(self.user_id)
        if not client_id:
            QMessageBox.critical(self, "Ошибка", "Клиент не найден. Обратитесь к администратору.")
            self.table.setRowCount(0)
            return

        requests = self.db.get_user_requests(client_id)
        self.table.setRowCount(len(requests))

        for row, request in enumerate(requests):
            self.table.setItem(row, 0, QTableWidgetItem(str(request['id'])))
            self.table.setItem(row, 1, QTableWidgetItem(str(request['request_date'])))
            self.table.setItem(row, 2, QTableWidgetItem(request['insurance_type']))
            self.table.setItem(row, 3, QTableWidgetItem(str(request['amount'])))
            self.table.setItem(row, 4, QTableWidgetItem(request['status']))

            # Кнопка для истории
            history_button = QPushButton("Показать историю")
            history_button.clicked.connect(lambda _, rid=request['id']: self.show_history(rid))
            self.table.setCellWidget(row, 5, history_button)

            # Кнопка для загрузки файла
            upload_button = QPushButton("Загрузить")
            upload_button.clicked.connect(lambda _, rid=request['id']: self.upload_file(rid))
            self.table.setCellWidget(row, 6, upload_button)

        self.table.resizeColumnsToContents()

    def show_history(self, request_id):
        history = self.db.get_request_history(request_id)
        history_text = "\n".join([f"{h['timestamp']}: {h['message']}" for h in history])
        QMessageBox.information(self, "История заявки", history_text or "История пуста")

    def upload_file(self, request_id):
        file_path, _ = QFileDialog.getOpenFileName(self, "Выберите файл")
        if file_path:
            upload_dir = "uploads"
            if not os.path.exists(upload_dir):
                os.makedirs(upload_dir)
            dest_path = os.path.join(upload_dir, os.path.basename(file_path))
            os.replace(file_path, dest_path)
            self.db.upload_attachment(request_id, dest_path)
            QMessageBox.information(self, "Успех", "Файл загружен")