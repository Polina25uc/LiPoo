-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Апр 18 2025 г., 19:25
-- Версия сервера: 8.0.30
-- Версия PHP: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `insurance_system`
--

-- --------------------------------------------------------

--
-- Структура таблицы `Attachments`
--

CREATE TABLE `Attachments` (
  `id` int NOT NULL,
  `request_id` int NOT NULL,
  `file_path` varchar(255) NOT NULL,
  `upload_time` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Attachments`
--

INSERT INTO `Attachments` (`id`, `request_id`, `file_path`, `upload_time`) VALUES
(1, 1, 'uploads/passport_scan_ivanov.jpg', '2025-04-18 17:10:13'),
(2, 2, 'uploads/property_doc_petrova.pdf', '2025-04-18 17:10:13'),
(3, 2, 'uploads\\test1.jpg', '2025-04-18 18:36:11');

-- --------------------------------------------------------

--
-- Структура таблицы `Clients`
--

CREATE TABLE `Clients` (
  `id` int NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Clients`
--

INSERT INTO `Clients` (`id`, `full_name`, `phone`, `email`) VALUES
(1, 'Иван Иванов', '+79001234567', 'ivanov@example.com'),
(2, 'Мария Петрова', '+79007654321', 'petrova@example.com');

-- --------------------------------------------------------

--
-- Структура таблицы `InsuranceTypes`
--

CREATE TABLE `InsuranceTypes` (
  `id` int NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `InsuranceTypes`
--

INSERT INTO `InsuranceTypes` (`id`, `name`, `description`) VALUES
(1, 'Автострахование', 'Страхование автомобиля от ущерба и угона'),
(2, 'Жилищное страхование', 'Страхование квартиры от пожара и затопления');

-- --------------------------------------------------------

--
-- Структура таблицы `RequestHistory`
--

CREATE TABLE `RequestHistory` (
  `id` int NOT NULL,
  `request_id` int NOT NULL,
  `timestamp` datetime NOT NULL,
  `message` text
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `RequestHistory`
--

INSERT INTO `RequestHistory` (`id`, `request_id`, `timestamp`, `message`) VALUES
(1, 1, '2025-04-18 17:10:13', 'Клиент отправил заявку'),
(2, 1, '2025-04-18 17:10:13', 'Оператор уточнил данные клиента');

-- --------------------------------------------------------

--
-- Структура таблицы `Requests`
--

CREATE TABLE `Requests` (
  `id` int NOT NULL,
  `client_id` int NOT NULL,
  `insurance_type_id` int NOT NULL,
  `request_date` date NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `commission` decimal(10,2) DEFAULT NULL,
  `status` varchar(50) DEFAULT NULL,
  `priority` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Requests`
--

INSERT INTO `Requests` (`id`, `client_id`, `insurance_type_id`, `request_date`, `amount`, `commission`, `status`, `priority`) VALUES
(1, 1, 1, '2024-01-15', '50000.00', '2500.00', 'Ожидает рассмотрения', 'Высокий'),
(2, 2, 2, '2024-02-20', '75000.00', '3000.00', 'Принята', 'Средний');

-- --------------------------------------------------------

--
-- Структура таблицы `Users`
--

CREATE TABLE `Users` (
  `id` int NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(100) NOT NULL,
  `role` enum('user','admin') NOT NULL,
  `email` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Дамп данных таблицы `Users`
--

INSERT INTO `Users` (`id`, `username`, `password`, `role`, `email`) VALUES
(1, 'admin', 'adminpass', 'admin', 'admin@example.com'),
(2, 'user1', 'userpass', 'user', 'ivanov@example.com'),
(3, '1', '1', 'user', 'petrova@example.com');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `Attachments`
--
ALTER TABLE `Attachments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`);

--
-- Индексы таблицы `Clients`
--
ALTER TABLE `Clients`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `InsuranceTypes`
--
ALTER TABLE `InsuranceTypes`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `RequestHistory`
--
ALTER TABLE `RequestHistory`
  ADD PRIMARY KEY (`id`),
  ADD KEY `request_id` (`request_id`);

--
-- Индексы таблицы `Requests`
--
ALTER TABLE `Requests`
  ADD PRIMARY KEY (`id`),
  ADD KEY `client_id` (`client_id`),
  ADD KEY `insurance_type_id` (`insurance_type_id`);

--
-- Индексы таблицы `Users`
--
ALTER TABLE `Users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `Attachments`
--
ALTER TABLE `Attachments`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `Clients`
--
ALTER TABLE `Clients`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `InsuranceTypes`
--
ALTER TABLE `InsuranceTypes`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `RequestHistory`
--
ALTER TABLE `RequestHistory`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `Requests`
--
ALTER TABLE `Requests`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT для таблицы `Users`
--
ALTER TABLE `Users`
  MODIFY `id` int NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `Attachments`
--
ALTER TABLE `Attachments`
  ADD CONSTRAINT `attachments_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `Requests` (`id`);

--
-- Ограничения внешнего ключа таблицы `RequestHistory`
--
ALTER TABLE `RequestHistory`
  ADD CONSTRAINT `requesthistory_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `Requests` (`id`);

--
-- Ограничения внешнего ключа таблицы `Requests`
--
ALTER TABLE `Requests`
  ADD CONSTRAINT `requests_ibfk_1` FOREIGN KEY (`client_id`) REFERENCES `Clients` (`id`),
  ADD CONSTRAINT `requests_ibfk_2` FOREIGN KEY (`insurance_type_id`) REFERENCES `InsuranceTypes` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
