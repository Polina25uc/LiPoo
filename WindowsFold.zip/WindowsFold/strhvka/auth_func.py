import mysql.connector
import sys
from PyQt6.QtWidgets import QApplication, QWidget, QMessageBox, QLineEdit
from PyQt6.QtCore import pyqtSignal
from authorization import Ui_Form
from user_window import UserWindow
from admin_window import AdminWindow
from mysql.connector import Error
import traceback

class AuthWindow(QWidget):
    auth_success = pyqtSignal(int, str)  # Сигнал для передачи user_id и role

    def __init__(self):
        super().__init__()
        self.con = None
        self.ui = Ui_Form()
        self.ui.setupUi(self)
        self.ui.lineEditPassword.setEchoMode(QLineEdit.EchoMode.Password)  # Скрыть пароль
        self.ui.pushButton.clicked.connect(self.authenticate)

        # Подключение к базе данных
        try:
            print("Попытка подключения к базе данных...")
            self.con = mysql.connector.connect(
                host='localhost',
                user='root',
                password='',
                database='insurance_system'
            )
            print("Подключение к базе данных успешно")
        except Error as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка подключения к базе данных: {e}")
            self.con = None

        # Подключение сигнала авторизации
        self.auth_success.connect(self.handle_auth_success)

    def authenticate(self):
        if not self.con or not self.con.is_connected():
            QMessageBox.critical(self, "Ошибка", "Нет соединения с базой данных")
            return

        username = self.ui.lineEditMail.text().strip()
        password = self.ui.lineEditPassword.text().strip()

        if not username or not password:
            QMessageBox.warning(self, "Ошибка", "Заполните все поля!")
            return

        try:
            print(f"Попытка авторизации для username: {username}")
            cursor = self.con.cursor(dictionary=True)
            query = "SELECT id, role FROM Users WHERE username = %s AND password = %s"
            cursor.execute(query, (username, password))
            result = cursor.fetchone()

            if result:
                print(f"Авторизация успешна: user_id={result['id']}, role={result['role']}")
                QMessageBox.information(self, "Успех", "Авторизация успешна!")
                self.auth_success.emit(result['id'], result['role'])
            else:
                QMessageBox.critical(self, "Ошибка", "Неверное имя пользователя или пароль!")

            cursor.close()

        except Error as e:
            QMessageBox.critical(self, "Ошибка", f"Ошибка при выполнении запроса: {e}")
            print(f"Ошибка SQL: {e}")

    def handle_auth_success(self, user_id, role):
        try:
            print(f"Открытие окна для роли: {role}")
            self.close()  # Закрываем окно авторизации
            if role == "admin":
                self.window = AdminWindow()
            elif role == "user":
                self.window = UserWindow(user_id)
            else:
                QMessageBox.critical(self, "Ошибка", f"Неизвестная роль: {role}")
                sys.exit(1)
            self.window.show()
        except Exception as e:
            print(f"Ошибка при открытии окна: {e}")
            traceback.print_exc()
            QMessageBox.critical(self, "Ошибка", f"Не удалось открыть окно: {e}")
            sys.exit(1)

    def closeEvent(self, event):
        if self.con and self.con.is_connected():
            print("Закрытие соединения с базой данных")
            self.con.close()
        event.accept()

if __name__ == "__main__":
    try:
        print("Запуск приложения...")
        app = QApplication(sys.argv)
        window = AuthWindow()
        window.show()
        print("Окно авторизации открыто")
        sys.exit(app.exec())
    except Exception as e:
        print(f"Ошибка при запуске приложения: {e}")
        traceback.print_exc()
        sys.exit(1)